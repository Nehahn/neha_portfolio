# Neha H.N. Portfolio

A responsive portfolio website created from the uploaded resume.

## Files
- `index.html` — portfolio content and structure
- `style.css` — responsive design and styling
- `script.js` — mobile navigation

## Run locally
Open `index.html` in any modern browser.

## Before publishing
Add real links for LinkedIn, GitHub, and any live project demos if available. The resume did not provide those URLs, so they were intentionally not invented.
